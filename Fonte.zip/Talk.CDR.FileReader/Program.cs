﻿using System;
using System.Threading.Tasks;
using Talk.CDR.FileReader.Enum;
using Talk.CDR.FileReader.Services;

namespace FIlerReader
{


    public class Arquivo
    {
        public Layout layout { get; set; }
        public string FileName { get; set; }
    }


    class Program
    {
        static async Task Main(string[] args)
        {

            ArquivoService service = new ArquivoService();

            string fileName = string.Empty;
            
            Console.WriteLine("Escolha o layout: \n1 - Claro\n2 - OI\n3 - IPCORP\n4 - TalkTelecom");
            var layoutKey =  Console.ReadKey().KeyChar.ToString();

            Layout layout = Layout.TALK;
            switch (layoutKey)
            {
                case "1":
                    layout = Layout.Claro;
                    break;
                case "2":
                    layout = Layout.OI;
                    break;
                case "3":
                    layout = Layout.IPCORP;
                    break;
                case "4":
                    layout = Layout.TALK;
                    break;
                default:
                    Console.Write("Layout inválido!");
                    break;
            }

            bool showDetail = true;
            if (args != null && args.Length > 0)
                fileName = args[0];

            if (args != null && args.Length > 1)
                showDetail = args[1] == "1" || args[1] == "true";

            await service.ReadFile(fileName, showDetail, layout);
           
        }

    }
}
