﻿using System;
namespace Talk.CDR.FileReader.Enum
{
   public enum Layout : int
    {
        Claro = 3,
        OI = 4,
        IPCORP = 2,
        TALK = 1
    }
}
